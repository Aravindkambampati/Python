Python 3.10.5 (tags/v3.10.5:f377153, Jun  6 2022, 16:14:13) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
str = 'argentina'
print(str[0:5:-1])

str[0:6:-1])
SyntaxError: unmatched ')'
str[0:6:-1]
''
str[-5:-9] + str[5:]
'tina'

================================ RESTART: Shell ================================
str1 = 'aravind'
str1.startswith('a')
True
str1.startswith('b')
False
str1.endswith('d')
True
str1.capitalize()
'Aravind'
