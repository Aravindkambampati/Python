str = 'argentina'
a = str[0:5]
b = a[::-1]
c = str[5:]
print(b+c)
