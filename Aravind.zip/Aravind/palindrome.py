Python 3.10.5 (tags/v3.10.5:f377153, Jun  6 2022, 16:14:13) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
a = 'NITIN
SyntaxError: unterminated string literal (detected at line 1)
a = 'NITIN'
b = a[::-1]
print(b)
NITIN
if a==b;
SyntaxError: invalid syntax
if a==b:
    print("it is a palindrome")
else:
    print("it is not a palindrome")

    
it is a palindrome
